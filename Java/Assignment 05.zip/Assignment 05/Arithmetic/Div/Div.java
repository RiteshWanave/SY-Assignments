package Arithmetic.Div;

public class Div {
    public void div(int a, int b) {
        System.out.println("Divison of " + a + " and " + b + " is " + (a / b));
    }
}
