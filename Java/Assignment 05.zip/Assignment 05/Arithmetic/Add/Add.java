package Arithmetic.Add;

public class Add {
    public void add(int a, int b) {
        System.out.println("sum of " + a + " and " + b + " is " + (a + b));
    }
}
