package Arithmetic.Sub;

public class Sub {
    public void sub(int a, int b) {
        System.out.println("subtraction of " + a + " and " + b + " is " + (a - b));
    }
}
