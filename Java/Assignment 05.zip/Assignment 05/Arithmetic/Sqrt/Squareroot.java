package Arithmetic.Sqrt;

public class Squareroot {
    public void squareroot(int a) {
        System.out.println("Squareroot of " + a + " is " + Math.sqrt(a));
    }
}
