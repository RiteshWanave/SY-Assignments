package Arithmetic.Sq;

public class Square {
    public void square(int a) {
        System.out.println("Square of " + a + " is " + (a * a));
    }
}
