package Arithmetic.Mul;

public class Mul {
    public void mul(int a, int b) {
        System.out.println("Multiplication of " + a + " and " + b + " is " + (a * b));
    }
}
